# MOUSE PRÓ 1.0 — projeto Android

Protótipo inicial para Android Studio, com interface escura/vermelha e serviço de acessibilidade experimental para teclas USB/OTG.

## Abrir e compilar
1. Extraia o ZIP em um computador.
2. Abra a pasta `MOUSE_PRO_v1.0` no Android Studio.
3. Aguarde a sincronização do Gradle e instale os componentes Android SDK solicitados.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Teste
1. Instale o APK no Android.
2. Abra MOUSE PRÓ e toque em **ABRIR ACESSIBILIDADE**.
3. Ative o serviço MOUSE PRÓ.
4. Conecte teclado USB por OTG e teste em um ambiente de treino, ajustando os pontos conforme o HUD.

## Limitações importantes
- Este ZIP contém código-fonte, não um APK compilado.
- Os pontos de toque são valores demonstrativos e podem precisar de ajuste conforme resolução, orientação e HUD.
- O protótipo mapeia J, Espaço, C e G para toques individuais.
- WASD contínuo, diagonais, mouse-look, botões do mouse e multitouch real ainda não estão implementados.
- Acessibilidade não garante compatibilidade com todos os jogos. Verifique as regras do jogo e não use funções proibidas.
- Não há garantia de funcionamento no Free Fire sem testes no aparelho.
