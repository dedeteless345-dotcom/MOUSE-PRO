plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.deehx.mousepro"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.deehx.mousepro"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
