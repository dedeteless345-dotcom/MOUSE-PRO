package com.deehx.mousepro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF101010.toInt())
        }

        val title = TextView(this).apply {
            text = "MOUSE PRÓ 1.0"
            textSize = 30f
            setTextColor(0xFFFF3030.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Mapeamento experimental de teclado USB/OTG\n\nJ = ação 1   |   Espaço = pulo\nC = agachar   |   G = parede de gel\n\nConfigure os pontos de toque antes de testar."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
        }
        val enable = Button(this).apply {
            text = "ABRIR ACESSIBILIDADE"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val note = TextView(this).apply {
            text = "Aviso: este protótipo não controla a câmera pelo movimento do mouse e pode não funcionar em todos os jogos. Use somente se permitido pelo jogo."
            textSize = 13f
            setTextColor(0xFFFFB0B0.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(description)
        root.addView(enable)
        root.addView(note)
        setContentView(root)
    }
}
