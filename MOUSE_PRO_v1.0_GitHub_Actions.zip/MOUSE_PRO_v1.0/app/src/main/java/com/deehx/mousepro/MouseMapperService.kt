package com.deehx.mousepro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class MouseMapperService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }

    override fun onInterrupt() { }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false

        val point = when (event.keyCode) {
            KeyEvent.KEYCODE_J -> Pair(0.78f, 0.78f)
            KeyEvent.KEYCODE_SPACE -> Pair(0.88f, 0.58f)
            KeyEvent.KEYCODE_C -> Pair(0.70f, 0.88f)
            KeyEvent.KEYCODE_G -> Pair(0.90f, 0.80f)
            else -> return false
        }
        tapRelative(point.first, point.second)
        return true
    }

    private fun tapRelative(xRatio: Float, yRatio: Float) {
        val metrics = resources.displayMetrics
        val x = metrics.widthPixels * xRatio
        val y = metrics.heightPixels * yRatio
        val path = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
