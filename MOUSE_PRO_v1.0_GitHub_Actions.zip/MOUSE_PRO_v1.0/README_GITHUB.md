# Compilar pelo GitHub Actions (sem AndroidIDE)

1. Crie um repositório no GitHub chamado `MOUSE-PRO`.
2. Envie **todo o conteúdo desta pasta** para a raiz do repositório (incluindo a pasta oculta `.github`).
3. Abra a aba **Actions** e selecione **Build MOUSE PRO APK**.
4. Toque em **Run workflow** se o fluxo não iniciar automaticamente após o envio.
5. Aguarde o trabalho terminar com marca verde. Abra a execução e baixe o artefato `MOUSE-PRO-v1.0-debug-apk`.
6. Extraia o ZIP do artefato: o APK estará dentro dele como `app-debug.apk`.

O APK só estará pronto se o job terminar com sucesso e o artefato existir. Este fluxo compila uma versão de depuração, não assinada para publicação na Play Store.
